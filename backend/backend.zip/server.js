import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import connectDB from "./config/db.js";
import authRoutes from "./routes/authRoutes.js";
import protect from "./middleware/authMiddleware.js";
import categoryRoutes from "./routes/categoryRoutes.js";
import "./routes/transactionRoutes.js";
import dashboardRoutes from "./routes/dashboardRoutes.js";
import insuranceRoutes from "./routes/insuranceRoutes.js";
import loanRoutes from "./routes/loanRoutes.js";
import retirementRoutes from "./routes/retirementRoutes.js";
import investmentRoutes from "./routes/investmentRoutes.js";
import transactionRoutes from "./routes/transactionRoutes.js";
import goalRoutes from "./routes/goalRoutes.js";
import analyticsRoutes from "./routes/analyticsRoutes.js";
import fireRoutes from "./routes/fireRoutes.js";
import reportRoutes from "./routes/reportRoutes.js";
import aiRoutes from "./routes/aiRoutes.js";
import notificationRoutes from "./routes/notificationRoutes.js";
import familyRoutes from "./routes/familyRoutes.js";
import memberRoutes from "./routes/member.routes.js";
import treasuryRoutes from "./routes/treasury.routes.js";
import contributionRoutes from "./routes/contribution.routes.js";
import familyTransactioRoutes from "./routes/familyTransaction.routes.js";
import familyInvestmentRoutes from "./routes/familyInvestment.routes.js";
import familyLoanRoutes from "./routes/familyLoan.routes.js";
import familyInsuranceRoutes from "./routes/familyInsurance.routes.js";
import familyGoalRoutes from "./routes/familyGoal.routes.js";
import treasuryRequestRoutes from "./routes/treasuryRequest.routes.js";
import treasuryBucketRoutes from "./routes/treasuryBucket.routes.js";
import familyAnalyticsRoutes from "./routes/familyAnalytics.routes.js";
import familyReportRoutes from "./routes/familyReport.routes.js";

dotenv.config();
connectDB();

const app = express();

app.use(cors({
    origin: process.env.client_URL,
    credentials: true
}));


app.use(express.json());
app.use(cookieParser());
app.use("/api/auth", authRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/transactions", transactionRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/insurance", insuranceRoutes);
app.use("/api/loans", loanRoutes);
app.use("/api/retirement", retirementRoutes);
app.use("/api/investments", investmentRoutes);
app.use("/api/goals", goalRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/fire", fireRoutes)
app.use("/api/reports", reportRoutes);
app.use("/api/ai", aiRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/family", familyRoutes);
app.use("/api/member", memberRoutes);
app.use("/api/treasury", treasuryRoutes);
app.use("/api/contributions", contributionRoutes);
app.use("/api/familyTransactions", familyTransactioRoutes)
app.use("/api/family-investments", familyInvestmentRoutes);
app.use("/api/family-loans", familyLoanRoutes);
app.use("/api/family-insurance", familyInsuranceRoutes);
app.use("/api/family-goals", familyGoalRoutes);
app.use("/api/treasury-requests", treasuryRequestRoutes);
app.use("/api/treasury-buckets", treasuryBucketRoutes);
app.use("/api/family-analytics", familyAnalyticsRoutes);
app.use("/api/family-reports", familyReportRoutes)

app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Aphelion API Running"
    });
});


const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});